#!/bin/sh
# kanaly.sh - manage subscriptions of the Nokia N9 Feeds app from the command line.
# Feeds keeps its subscriptions in Tracker (no config file). Changes go through the
# feed engine on D-Bus; reading and clearing use tracker-sparql (package tracker-utils),
# the only command-line tools that Aegis lets into Tracker.
# Run as root or as user; root re-runs the script as user.
# SCRIPT_VERSION=4  (MeeRevive shows it; 3 = before backup/restore)
#
#   sh kanaly.sh list                 subscribed feeds (address and title)
#   sh kanaly.sh add URL [URL...]     subscribe
#   sh kanaly.sh remove URL [URL...]  unsubscribe (also deletes its posts)
#   sh kanaly.sh import FILE          subscribe every URL in FILE (one per line, # = comment)
#   sh kanaly.sh backup [FILE]        save the list of feeds (default MyDocs/MeeRevive/feeds.txt)
#   sh kanaly.sh restore [FILE]       subscribe every feed from a backup (same default file)
#   sh kanaly.sh refresh              refresh all feeds now
#   sh kanaly.sh clear                delete all downloaded posts, in Feeds and on the
#                                     Events (Feed) home screen; subscriptions stay
#   sh kanaly.sh clear-events         only remove Feeds posts from the Events home screen
#
# Designed and written by Claude (Anthropic) together with smyhu for the Nokia N9. MIT licence.

if [ "$(id -u)" = 0 ]; then
    q=""
    for a in "$@"; do q="$q '$a'"; done
    exec devel-su user -c "sh '$0' $q"
fi

# the user session bus (Tracker and the feed engine live there)
if [ -z "$DBUS_SESSION_BUS_ADDRESS" ] && [ -f /tmp/session_bus_address.user ]; then
    c=$(cat /tmp/session_bus_address.user)
    case "$c" in
        export*|DBUS_SESSION_BUS_ADDRESS=*) eval "$c"; export DBUS_SESSION_BUS_ADDRESS ;;
        *) export DBUS_SESSION_BUS_ADDRESS="$c" ;;
    esac
fi

BACKUP=/home/user/MyDocs/MeeRevive/feeds.txt

EVENTS="dbus-send --session --type=method_call --print-reply --dest=com.nokia.home.EventFeed /eventfeed com.nokia.home.EventFeed"
ENGINE="dbus-send --session --type=method_call --print-reply --dest=com.nokia.FeedEngine / com.nokia.FeedEngine"

need_tracker() {
    if ! [ -x /usr/bin/tracker-sparql ]; then
        echo "tracker-sparql is missing. As root run:  apt-get install tracker-utils"
        exit 1
    fi
}

# lines "urn link title" of all subscribed feeds
channels() {
    tracker-sparql -q "SELECT ?u ?l ?t WHERE { ?u a mfo:FeedChannel ; nie:links ?l . OPTIONAL { ?u nie:title ?t } }" |
        sed -n 's/^ *\(urn:[^,]*\), \([^,]*\)\(, \(.*\)\)\{0,1\}$/\1 \2 \4/p'
}

urn_of() {
    channels | while read -r urn link title; do
        [ "$link" = "$1" ] && { echo "$urn"; break; }
    done
}

# Feeds posts on the Events home screen use the channel urn as source name
clear_events() {
    n=0
    for urn in $(channels | cut -d' ' -f1); do
        $EVENTS.removeItemsBySourceName "string:$urn" >/dev/null && n=$((n + 1))
        # older Feeds versions: source name without the urn: prefix
        $EVENTS.removeItemsBySourceName "string:${urn#urn:uuid:}" >/dev/null
    done
    echo "Events screen: $n feeds cleared"
}

cmd=$1
[ $# -gt 0 ] && shift
case "$cmd" in
    list)
        need_tracker
        channels | while read -r urn link title; do echo "$link   $title"; done |
            sed 's/&lt;/</g; s/&gt;/>/g; s/&quot;/"/g; s/&#039;/'"'"'/g; s/&amp;/\&/g' ;;
    add)
        for u in "$@"; do echo "+ $u"; $ENGINE.subscribe "array:string:$u" string:rssatom >/dev/null; done ;;
    remove)
        need_tracker
        for u in "$@"; do
            urn=$(urn_of "$u")
            if [ -z "$urn" ]; then echo "not subscribed: $u"; continue; fi
            echo "- $u"; $ENGINE.unsubscribe "string:$urn" >/dev/null
        done ;;
    backup)
        need_tracker
        f=${1:-$BACKUP}
        mkdir -p "$(dirname "$f")" || exit 1
        { echo "# Nokia N9 Feeds backup $(date '+%Y-%m-%d %H:%M') - restore: sh kanaly.sh restore FILE"
          channels | while read -r urn link title; do echo "$link   $title"; done |
            sed 's/&lt;/</g; s/&gt;/>/g; s/&quot;/"/g; s/&#039;/'"'"'/g; s/&amp;/\&/g'
        } > "$f" || exit 1
        echo "$(grep -vc '^#' "$f") feeds saved to $f" ;;
    import|restore)
        [ $# -eq 0 ] && [ "$cmd" = restore ] && set -- "$BACKUP"
        [ -f "$1" ] || { echo "No file: $1"; exit 1; }
        grep -v '^[[:space:]]*#' "$1" | while read -r u rest; do
            [ -n "$u" ] || continue
            echo "+ $u"; $ENGINE.subscribe "array:string:$u" string:rssatom >/dev/null
        done ;;
    refresh)
        need_tracker
        list=""
        for urn in $(channels | cut -d' ' -f1); do list="$list,$urn"; done
        [ -n "$list" ] && $ENGINE.refresh "array:string:${list#,}" >/dev/null && echo "refresh started" ;;
    clear-events)
        need_tracker
        clear_events ;;
    clear)
        need_tracker
        clear_events
        tracker-sparql -u -q "DELETE { ?e a rdfs:Resource } WHERE { ?e a mfo:Enclosure ; nie:isLogicalPartOf ?m . ?m a mfo:FeedMessage }" >/dev/null
        tracker-sparql -u -q "DELETE { ?m a rdfs:Resource } WHERE { ?m a mfo:FeedMessage }" && echo "posts deleted" ;;
    *)
        sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//' ; exit 1 ;;
esac
