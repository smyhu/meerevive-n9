TLS 1.2 patch for Nokia N9: https://github.com/smyhu/n9-tls (MIT; OpenSSL licence for OpenSSL,
LGPL for the rebuilt Qt/curl libraries, sources in that repository).
