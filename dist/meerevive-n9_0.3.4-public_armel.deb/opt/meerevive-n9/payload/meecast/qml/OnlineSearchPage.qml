import Qt 4.7
import com.nokia.meego 1.0

// N9 project (23.10.2026): find any place in the world with the free
// Open-Meteo geocoding service and add it as an "open-meteo.com" location.
// The location code is "latitude,longitude", the format the openmeteocom
// converter expects.

Page {
    id: onlinesearch
    property int margin: 16
    property string status: ""
    orientationLock: PageOrientation.LockPortrait

    tools: ToolBarLayout {
        ToolIcon {
            iconId: "toolbar-back"
            onClicked: { pageStack.pop(); }
        }
    }

    ListModel { id: results }

    function search(text)
    {
        text = text.replace(/^\s+|\s+$/g, "");
        results.clear();
        if (text.length < 2) {
            status = "Wpisz co najmniej 2 litery";
            return;
        }
        status = "Szukam...";
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState != XMLHttpRequest.DONE)
                return;
            if (xhr.status != 200) {
                status = "Błąd połączenia (" + xhr.status + ")";
                return;
            }
            var data;
            try {
                data = JSON.parse(xhr.responseText);
            } catch (e) {
                status = "Błędna odpowiedź serwera";
                return;
            }
            var list = data.results ? data.results : [];
            for (var i = 0; i < list.length; i++) {
                var r = list[i];
                var region = r.admin1 ? r.admin1 : "";
                var country = r.country ? r.country : (r.country_code ? r.country_code : "");
                var detail = region;
                if (r.admin2 && r.admin2 != region)
                    detail = r.admin2 + (region ? ", " + region : "");
                results.append({
                    "name": r.name,
                    "detail": detail + (detail ? ", " : "") + country,
                    "region": region,
                    "country": country,
                    "lat": r.latitude,
                    "lon": r.longitude
                });
            }
            status = list.length ? "" : "Nic nie znaleziono";
        }
        xhr.open("GET", "http://geocoding-api.open-meteo.com/v1/search?count=30&language=pl&format=json&name="
                 + encodeURIComponent(text));
        xhr.send();
    }

    Rectangle {
        anchors.fill: parent
        color: "black"
    }

    Label {
        id: title
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.leftMargin: margin
        height: 80
        color: "white"
        text: "Szukaj w internecie"
        font.pixelSize: 30
        verticalAlignment: Text.AlignVCenter
    }

    TextField {
        id: query
        anchors.top: title.bottom
        anchors.left: parent.left
        anchors.right: searchbutton.left
        anchors.leftMargin: margin
        anchors.rightMargin: margin
        placeholderText: "Miejscowość, np. Lizbona"
        inputMethodHints: Qt.ImhNoPredictiveText
        Keys.onReturnPressed: { onlinesearch.search(query.text); onlinesearch.focus = true; }
        Keys.onEnterPressed: { onlinesearch.search(query.text); onlinesearch.focus = true; }
    }
    Button {
        id: searchbutton
        anchors.top: title.bottom
        anchors.right: parent.right
        anchors.rightMargin: margin
        width: 150
        text: "Szukaj"
        onClicked: { onlinesearch.focus = true; onlinesearch.search(query.text); }
    }

    Label {
        id: statuslabel
        anchors.top: query.bottom
        anchors.topMargin: 10
        anchors.left: parent.left
        anchors.leftMargin: margin
        color: "#aaaaaa"
        text: status
        visible: status != ""
    }

    ListView {
        id: resultlist
        anchors.top: statuslabel.visible ? statuslabel.bottom : query.bottom
        anchors.topMargin: 10
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.leftMargin: margin
        anchors.rightMargin: margin
        clip: true
        model: results
        delegate: Item {
            width: resultlist.width
            height: 90
            Column {
                anchors.left: parent.left
                anchors.right: addicon.left
                anchors.verticalCenter: parent.verticalCenter
                Label {
                    width: parent.width
                    text: model.name
                    color: "white"
                    elide: Text.ElideRight
                }
                Label {
                    width: parent.width
                    text: model.detail
                    color: "#aaaaaa"
                    font.pixelSize: 20
                    elide: Text.ElideRight
                }
            }
            Image {
                id: addicon
                source: "image://theme/icon-s-common-add-inverse"
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
            }
            MouseArea {
                anchors.fill: parent
                onClicked: {
                    var code = Number(model.lat).toFixed(4) + "," + Number(model.lon).toFixed(4);
                    Config.saveStation1(code, model.name, model.region, model.country,
                                        "open-meteo.com", 0, false,
                                        Number(model.lat), Number(model.lon));
                    pageStack.pop(pageStack.find(function(page) { return page.objectName == "stationspage" }));
                }
            }
        }
    }
}
