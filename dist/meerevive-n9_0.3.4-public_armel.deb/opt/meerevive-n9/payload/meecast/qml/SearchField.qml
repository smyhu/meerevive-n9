import Qt 4.7
import com.nokia.meego 1.0

// Patched for the N9 project (23.10.2026):
// - filters while typing (the original waited for Enter, which the N9
//   keyboard swallows together with the predicted word),
// - matches anywhere in the name, ignoring case and Polish diacritics
//   ("krakow" finds "Kraków"),
// - word prediction is off in this field.

Item {
    id: searchfield
    width: parent.width

    property QtObject model: undefined
    property QtObject fullModel
    property QtObject filtermodel: ListModel{}

    property string filter: ""
    property string first_string: ""
    property string second_string: ""

    signal filtered();

    Component.onCompleted: {
        fullModel = model;
        fillModel();
    }
    function fillModel()
    {
        filtermodel.clear();
        for (var i = 0; i < fullModel.count; i++) {
            filtermodel.append(fullModel.get(i))
        }
    }
    function plain(s)
    {
        var from = "ąćęłńóśźżĄĆĘŁŃÓŚŹŻ";
        var to   = "acelnoszzACELNOSZZ";
        var out = "";
        for (var i = 0; i < s.length; i++) {
            var k = from.indexOf(s.charAt(i));
            out += (k >= 0) ? to.charAt(k) : s.charAt(i);
        }
        return out.toUpperCase();
    }
    function find()
    {
        fillModel();
        if (filter.length > 0){
            first_string = plain(filter);
            for (var i=filtermodel.count-1; i >= 0; i--){
                second_string = plain(filtermodel.get(i).name);
                if (second_string.indexOf(first_string) < 0){
                    filtermodel.remove(i);
                }
            }
        }
        searchfield.filtered();
    }

    Row {
        width: parent.width
        TextField {
            id: searchInput
            placeholderText: Config.tr("Enter search")
            width: parent.width
            inputMethodHints: Qt.ImhNoPredictiveText

            Image {
                id: clearText
                source: 'image://theme/icon-m-input-clear'
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter

                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        searchInput.text = "";
                    }
                }
            }
            maximumLength: 50

            onTextChanged: {
                var f = searchInput.text;
                f = f.replace(/\s*$/g,"");
                f = f.replace(/^\s*/g,"");
                filter = f;
                searchfield.find();
            }

            Keys.onReturnPressed: {
                searchfield.focus = true;
            }
            Keys.onEnterPressed: {
                searchfield.focus = true;
            }
        }
    }
}
